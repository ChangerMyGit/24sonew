<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('gbk');
E_D("DROP TABLE IF EXISTS `p_diymen_set`;");
E_C("CREATE TABLE `p_diymen_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(60) NOT NULL,
  `appid` varchar(18) NOT NULL,
  `appsecret` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=gbk");
E_D("replace into `p_diymen_set` values('1','aeovsr1401849750','','');");
E_D("replace into `p_diymen_set` values('2','cnjpqo1401935820','','');");
E_D("replace into `p_diymen_set` values('3','879c2f933017228','','');");
E_D("replace into `p_diymen_set` values('28','gdfrep1402472524','wx68350ef9a398e2a5','bf6fa839097a267608c9ba6170deb455');");
E_D("replace into `p_diymen_set` values('4','kpnsmf1401940888','wx2cfc729689a2c729','9797423cb51060c7836e8372ac5fbdb9');");
E_D("replace into `p_diymen_set` values('5','dnohtd1401942382','','');");
E_D("replace into `p_diymen_set` values('6','wfxurg1401948445','wxe89b5070f5b47443','a67827bf152519ab04fe1e4f0cd383d0');");
E_D("replace into `p_diymen_set` values('7','a0bbb64eef61a16','wx3c6639112d0430e5','642f8ccf24c7805cf7de855909975bce');");
E_D("replace into `p_diymen_set` values('8','mhsqxc1401953951',' wx2cfc729689a2c72','01ef5d299941186b6e7ccb725e481ac0');");
E_D("replace into `p_diymen_set` values('9','1d36324a811c583','wxf09d6d98a17dc060','56efa7a75de09248d2099ef47aa49b0f');");
E_D("replace into `p_diymen_set` values('10','mvbqrw1402035786','','');");
E_D("replace into `p_diymen_set` values('11','ocbtfr1402282562','wx6f16a9d89100d173','64ecb4539f38846bfc407d4c4699b1c7');");
E_D("replace into `p_diymen_set` values('12','a3a7daf71176d5b','','');");
E_D("replace into `p_diymen_set` values('17','dgqaqc1402307446','wx8dd6fafec3976f60','d9c44d5272d4faeb259c52f8c116475b');");
E_D("replace into `p_diymen_set` values('13','tvjxcc1402290548','wx31582dd27a0401a8','d013513f052b73c84f5cd9a5f0f31687');");
E_D("replace into `p_diymen_set` values('14','ainbtq1402292243','wxa63adbe3e23946dc','84a578a082bae989ffd8fc18152cfe0e');");
E_D("replace into `p_diymen_set` values('15','vhvake1402306510','wx5553e3495e871096','4c807cd7990e043fac8096cb405ff823');");
E_D("replace into `p_diymen_set` values('16','glkpuw1402307164','wx1c8f8556237494a6','6b5994fe0a3471c2b9eb0c92c025d89e');");
E_D("replace into `p_diymen_set` values('18','dhybwc1402363778','wxd033b0717b1c9b74','ff9af761fef12e5a83babbcd9b8423a7');");
E_D("replace into `p_diymen_set` values('19','c6a3b2d7590ae01','wxad267d4111c286a4','898de406101ce5038762d0007780ac84');");
E_D("replace into `p_diymen_set` values('20','aricpn1402370263','wx8dd6fafec3976f60','d9c44d5272d4faeb259c52f8c116475b');");
E_D("replace into `p_diymen_set` values('21','yosjzs1402383816','wx8dd6fafec3976f60','d9c44d5272d4faeb259c52f8c116475b');");
E_D("replace into `p_diymen_set` values('22','sordml1402391844','','');");
E_D("replace into `p_diymen_set` values('23','6845f758f8e1a94','wxf76d5e4aff1c286f','b6f85224a451f23763710e8b5d4c2f91');");
E_D("replace into `p_diymen_set` values('24','f0cdf4ad5650e89','wxd033b0717b1c9b74','ff9af761fef12e5a83babbcd9b8423a7');");
E_D("replace into `p_diymen_set` values('25','junxtg1402455483','wx9eb1431a79a0b04b','8f6ed64b8fcd5a12da174092f3dd7dbb');");
E_D("replace into `p_diymen_set` values('26','85fa9a93c81ad7e','wx69fc3e3a98a8a3c4','b8529311df3f6a2af54633ede0e642dc');");
E_D("replace into `p_diymen_set` values('27','qxrzxy1402460503','wx277af689fe79dd62','3d49c511e6a796145f1edd8157ef4527');");
E_D("replace into `p_diymen_set` values('29','rzxdlc1402480377','','');");
E_D("replace into `p_diymen_set` values('30','ufjfqw1402534773','wx67fdf5cdf5883c36','a2bb71281b18190d3bc5632a3df51e71');");
E_D("replace into `p_diymen_set` values('31','zupfww1402732348','','');");
E_D("replace into `p_diymen_set` values('32','gjnknc1402732643','','');");
E_D("replace into `p_diymen_set` values('33','mleyln1402732919','wx5e6beedfbd15c0b4','71db6e4549bd61eae5cd47351fa174f5');");
E_D("replace into `p_diymen_set` values('34','befcoq1402738281','wx0088d2e7689316aa','5fb03f45ec4a8483da40d36c5b22a6cd');");
E_D("replace into `p_diymen_set` values('35','diwxqe1402738986','wx41cfb03d6707a720','9d2c9a5e7a4ce6f5ce68e74a738fe97d');");
E_D("replace into `p_diymen_set` values('36','apzdcd1402792543','wx0088d2e7689316aa','5fb03f45ec4a8483da40d36c5b22a6cd');");
E_D("replace into `p_diymen_set` values('37','kcmjgr1402792677','wx0088d2e7689316aa','5fb03f45ec4a8483da40d36c5b22a6cd');");
E_D("replace into `p_diymen_set` values('38','ftxvbg1402882875','wx9a554f9ed9d418f7','c2b958165f4c6c4e3e3bf34079cbcb5a');");
E_D("replace into `p_diymen_set` values('39','kcbvom1402885756','wxe4ae20ec44d2f26f','5ee1874672500ff51a2c5b4a2ef02521');");
E_D("replace into `p_diymen_set` values('40','oucryx1402886291','wx5e6beedfbd15c0b4','71db6e4549bd61eae5cd47351fa174f5');");
E_D("replace into `p_diymen_set` values('41','qnrwlm1402888833','wxe4f6271bcdb9f4da','44a5c230600078eb8a876672799b6ae3');");
E_D("replace into `p_diymen_set` values('42','ihzurz1402906257','','');");
E_D("replace into `p_diymen_set` values('43','0d8553ddf4f8102','wxfcbb7e1891ed5f93','b5042da2a0183fc6926bf7813b93f12a');");
E_D("replace into `p_diymen_set` values('44','ysemxs1402913598','wx350928cbd12b72e0','bbd90dd1beac2e648acc2f29630d663e');");
E_D("replace into `p_diymen_set` values('45','gqynxp1402964340','','');");
E_D("replace into `p_diymen_set` values('46','babhpu1402976106','','');");
E_D("replace into `p_diymen_set` values('47','xgmone1402987078','wxb4338227e83dbcb1','2cdcdb2d352f3b1696b7f816f8d27e45');");
E_D("replace into `p_diymen_set` values('48','owitol1402987860','wx6c7220ddb506adf4','5137c4ff46325789c7a7c0d435a798b0');");
E_D("replace into `p_diymen_set` values('49','rokrvs1402991164','wx8c06896621dc63b6','f343b61bb6087d5312d10757502bad12');");
E_D("replace into `p_diymen_set` values('50','qweeqm1402996029','wx404a056cdd0556f9','07049f4885254e8dcf0a511505ef7633');");
E_D("replace into `p_diymen_set` values('51','eujhzm1403053453','','');");
E_D("replace into `p_diymen_set` values('52','hzuwcs1403055548','','');");
E_D("replace into `p_diymen_set` values('53','d2c798c7f728898','wxd1843c5b5faacf19','7f4f1db35782e88bb2c46c332843634d');");
E_D("replace into `p_diymen_set` values('54','bjavmy1403059259','','');");
E_D("replace into `p_diymen_set` values('55','wobdpx1403067571','','');");
E_D("replace into `p_diymen_set` values('56','obaoje1403070301','wxe117ff83c570124f','5d861d17f2cbcec8eb560225f742a25d');");
E_D("replace into `p_diymen_set` values('57','hjgbda1403071260','wx82cf1034028f46cb','89c818e2a925f0e29320b298714a46ff');");
E_D("replace into `p_diymen_set` values('58','voprih1403071796','','');");
E_D("replace into `p_diymen_set` values('59','bmcesv1403074849','wx9eb1431a79a0b04b','8f6ed64b8fcd5a12da174092f3dd7dbb');");

require("../../inc/footer.php");
?>